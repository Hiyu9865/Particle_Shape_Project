import os, sys
# Ensure the package under ../ is importable as `pyshape`
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
